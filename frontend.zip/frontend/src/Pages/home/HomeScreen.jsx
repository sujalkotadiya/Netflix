import Navbar from "../../components/Navbar";

const HomeScreen = () => {

	return <>
    <Navbar/>
    </>;
}

export default HomeScreen